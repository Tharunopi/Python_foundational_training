class Vechicle:
    def __init__(self, vechiceID, make, model, year, dailyRate, status, passengerCapacity, engineCapacity):
        self.vechiceID = vechiceID
        self.make = make
        self.model = model
        self.year = year
        self.daiyRate = dailyRate
        self.status = status
        self.passengerCapacity = passengerCapacity
        self.engineCapacity= engineCapacity